$PreLoad = {}
$PostLoad = {}
$Config = {}
$Shutdown = {}