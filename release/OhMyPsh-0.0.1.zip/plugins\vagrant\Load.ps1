$PreLoad = {}

$PostLoad = {
    Write-Output "Vagrant status module loaded. Use Write-VagrantStatusDetailed for information about current vagrant boxes."
}
$config = {}
$Shutdown = {}