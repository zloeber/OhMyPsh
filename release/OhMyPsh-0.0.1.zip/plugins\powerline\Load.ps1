$PreLoad = {
    Import-OMPModule 'Powerline'
}
$PostLoad = {}
$Config = {}
$Shutdown = {}