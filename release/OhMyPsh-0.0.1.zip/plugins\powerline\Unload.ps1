$Unload = {
    Remove-OMPModule -Name 'powerline' -PluginSafe
}