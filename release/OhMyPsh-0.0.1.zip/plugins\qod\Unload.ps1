$Unload = {
    Remove-OMPProfileSetting -Name 'QuoteDirectory'
}