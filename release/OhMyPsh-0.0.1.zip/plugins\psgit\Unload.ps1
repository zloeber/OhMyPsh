$Unload = {
    Remove-OMPModule -Name 'psgit' -PluginSafe
}