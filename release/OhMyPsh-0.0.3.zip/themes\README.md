#OhMyPsh Themes

Themes are simple scripts that mostly just setup your prompt function or console colors (or both).

You are also free to add code in your theme script to modify output of types via PScolor (See Add-OMPColorAction and Get-OMPColorAction).

Any other code or settings should be done in their respective plugin (ie. PSReadline or PSGit settings).

Note: When loading OhMyPsh the plugins load before the themes so you CAN override plugin
settings in a theme file if you are so inclined.
