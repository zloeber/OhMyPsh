﻿---
external help file: OhMyPsh-help.xml
Module Name: OhMyPsh
online version: https://www.github.com/zloeber/OhMyPsh
schema: 2.0.0
---

# Show-OMPStatus

## SYNOPSIS
Shows OhMyPsh basic status information.

## SYNTAX

```
Show-OMPStatus
```

## DESCRIPTION
Shows OhMyPsh basic status information.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Show-OMPStatus
```

Shows OhMyPsh status information.

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

[https://www.github.com/zloeber/OhMyPsh](https://www.github.com/zloeber/OhMyPsh)

