﻿---
external help file: OhMyPsh-help.xml
Module Name: OhMyPsh
online version: https://github.com/zloeber/OhMyPsh
schema: 2.0.0
---

# Write-OMPGitStatus

## SYNOPSIS
Outputs to the screen a short output of the current directory git status.

## SYNTAX

```
Write-OMPGitStatus
```

## DESCRIPTION
Outputs to the screen a short output of the current directory git status.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Write-OMPGitStatus
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber

## RELATED LINKS

[https://github.com/zloeber/OhMyPsh](https://github.com/zloeber/OhMyPsh)

