$UnLoad = {
    Remove-OMPProfileSetting -Name 'ModuleAutoUpgradeFrequency'
}