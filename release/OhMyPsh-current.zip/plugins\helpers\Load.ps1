$PreLoad = {}
$PostLoad = {}
$Config = {}
$Shutdown = {}
$UnLoad = {}