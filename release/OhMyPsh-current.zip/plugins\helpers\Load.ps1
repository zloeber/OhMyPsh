$PreLoad = {}
$PostLoad = {}
$Shutdown = {}