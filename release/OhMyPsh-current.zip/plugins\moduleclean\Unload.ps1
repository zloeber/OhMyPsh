$Unload = {
    Remove-OMPProfileSetting -Name 'ModuleAutoCleanFrequency'
}