﻿---
external help file: OhMyPsh-help.xml
Module Name: OhMyPsh
online version: https://github.com/zloeber/OhMyPsh
schema: 2.0.0
---

# Test-OMPInAGitRepo

## SYNOPSIS
Validate if the current path is a git repo.

## SYNTAX

```
Test-OMPInAGitRepo
```

## DESCRIPTION
Validate if the current path is a git repo.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Test-OMPInAGitRepo
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber

## RELATED LINKS

[https://github.com/zloeber/OhMyPsh](https://github.com/zloeber/OhMyPsh)

