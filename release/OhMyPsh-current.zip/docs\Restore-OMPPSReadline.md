﻿---
external help file: OhMyPsh-help.xml
Module Name: OhMyPsh
online version: https://www.github.com/zloeber/OhMyPsh
schema: 2.0.0
---

# Restore-OMPPSReadline

## SYNOPSIS
Restores the original PSReadline colors and settings.

## SYNTAX

```
Restore-OMPPSReadline
```

## DESCRIPTION
Restores the original PSReadline colors and settings.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Restore-OMPPSReadline
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber

## RELATED LINKS

[https://www.github.com/zloeber/OhMyPsh](https://www.github.com/zloeber/OhMyPsh)

