$PreLoad = {}
$PostLoad = {}
$Config = {}
$Shutdown = {}
$Unload = {}