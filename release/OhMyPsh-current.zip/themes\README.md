#OhMyPsh Themes

Themes are simple scripts that mostly just setup your prompt, console colors, and console title. Ideally, any other code or settings should be done in their respective plugin (ie. PSReadline).

Note: When OhMyPsh starts the plugins load before themes so you CAN override plugin
settings in a theme file if you are so inclined.

Another Note: Themes are a bit loose right now and are quite sensitive to errors returned in the error stream.
