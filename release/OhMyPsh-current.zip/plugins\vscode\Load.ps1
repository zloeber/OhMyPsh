$PreLoad = {
    $Global:PSModuleAutoloadingPreference = 'none'
    $Global:PSDefaultParameterValues.Clear()
}
$PostLoad = {}
$Config = {}
$Shutdown = {}
$Unload = {}