$PreLoad = {
    Import-OMPModule 'Powerline'
}
$PostLoad = {
}