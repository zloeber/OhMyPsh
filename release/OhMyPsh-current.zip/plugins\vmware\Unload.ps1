$Unload = {
   # Remove-Module Initialize-VMware_VimAutomation_Cis -Force
    Remove-OMPModule -Name 'VMware*' -PluginSafe
}