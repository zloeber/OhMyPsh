﻿---
external help file: OhMyPsh-help.xml
Module Name: OhMyPsh
online version: https://www.github.com/zloeber/OhMyPsh
schema: 2.0.0
---

# Remove-OMPPlugin

## SYNOPSIS
Removes a loaded plugin

## SYNTAX

```
Remove-OMPPlugin [-Force] [-NoProfileUpdate]
```

## DESCRIPTION
Removes a loaded plugin

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Remove-OMPPlugin -Name o365
```

## PARAMETERS

### -Force
Attempt to remove a plugin that doesn't show as being loaded

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: 

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

### -NoProfileUpdate
Skip updating the profile

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: 

Required: False
Position: Named
Default value: False
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber

## RELATED LINKS

[https://www.github.com/zloeber/OhMyPsh](https://www.github.com/zloeber/OhMyPsh)

