<#
    Another one of Joel Bennett's works.
    This is an example of an advanced theme with some additional module requirements.
#>
Set-OMPGitOutput -Name 'psgit'
Import-OMPModule PowerLine